from pathlib import Path
from fastapi import FastAPI, Depends, HTTPException, Query
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from sqlalchemy import or_, func

from .database import Base, engine, get_db
from . import models, schemas

BASE_DIR = Path(__file__).resolve().parent.parent
FRONTEND_DIR = BASE_DIR / "frontend"

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Inventory Management System API",
    description="A simple college mini-project to manage stock products.",
    version="1.0.0"
)

@app.get("/api/health")
def health_check():
    return {"status": "ok", "message": "Inventory API is running"}

@app.get("/api/dashboard")
def dashboard(db: Session = Depends(get_db)):
    total_products = db.query(models.Product).count()
    total_units = db.query(func.coalesce(func.sum(models.Product.quantity), 0)).scalar()
    total_value = db.query(
        func.coalesce(func.sum(models.Product.quantity * models.Product.price), 0.0)
    ).scalar()
    low_stock = db.query(models.Product).filter(models.Product.quantity <= 5).count()
    return {
        "total_products": total_products,
        "total_units": int(total_units or 0),
        "total_value": round(float(total_value or 0), 2),
        "low_stock": low_stock
    }

@app.get("/api/products", response_model=list[schemas.ProductOut])
def list_products(
    search: str = Query(default="", max_length=120),
    db: Session = Depends(get_db)
):
    query = db.query(models.Product)
    if search.strip():
        term = f"%{search.strip()}%"
        query = query.filter(or_(
            models.Product.name.ilike(term),
            models.Product.category.ilike(term),
            models.Product.supplier.ilike(term)
        ))
    return query.order_by(models.Product.id.desc()).all()

@app.post("/api/products", response_model=schemas.ProductOut, status_code=201)
def create_product(product: schemas.ProductCreate, db: Session = Depends(get_db)):
    new_product = models.Product(**product.model_dump())
    db.add(new_product)
    db.commit()
    db.refresh(new_product)
    return new_product

@app.put("/api/products/{product_id}", response_model=schemas.ProductOut)
def update_product(product_id: int, product: schemas.ProductUpdate, db: Session = Depends(get_db)):
    existing = db.query(models.Product).filter(models.Product.id == product_id).first()
    if existing is None:
        raise HTTPException(status_code=404, detail="Product not found")
    for key, value in product.model_dump().items():
        setattr(existing, key, value)
    db.commit()
    db.refresh(existing)
    return existing

@app.delete("/api/products/{product_id}")
def delete_product(product_id: int, db: Session = Depends(get_db)):
    existing = db.query(models.Product).filter(models.Product.id == product_id).first()
    if existing is None:
        raise HTTPException(status_code=404, detail="Product not found")
    db.delete(existing)
    db.commit()
    return {"message": "Product deleted successfully"}

# Serve the frontend from the same FastAPI app so frontend and backend work together.
app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="frontend")
