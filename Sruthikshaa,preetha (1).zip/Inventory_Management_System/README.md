# Inventory Management System

A beginner-friendly college mini-project using HTML, CSS, JavaScript, Python FastAPI, SQLAlchemy and SQLite.

## Features
- Create, view, update and delete products (CRUD)
- Search by product name, category or supplier
- Dashboard counts for products, units, stock value and low-stock items
- Input validation and confirmation before deletion
- SQLite database persists data locally

## Requirements
- Python 3.10 or newer
- Visual Studio Code
- Python extension in VS Code (recommended)

## Run in VS Code (Windows)
1. Extract this project folder and open `Inventory_Management_System` in VS Code.
2. Open **Terminal > New Terminal**.
3. Create a virtual environment:
   `py -m venv .venv`
4. Activate it in PowerShell:
   `.\.venv\Scripts\Activate.ps1`
   If PowerShell blocks activation, run `.\.venv\Scripts\python.exe -m pip install -r backend/requirements.txt` and then `.\.venv\Scripts\python.exe -m uvicorn backend.main:app --reload` instead.
5. Install packages:
   `python -m pip install -r backend/requirements.txt`
6. Start the application from the project root:
   `python -m uvicorn backend.main:app --reload`
7. Open `http://127.0.0.1:8000` in your browser.
8. API documentation: `http://127.0.0.1:8000/docs`.

## Database
SQLite database file `inventory.db` is created automatically in the project root when the app starts. Do not move the database file while the app is running.

## Quick test checklist
- Add a product with quantity 10 and price 25.
- Confirm the product appears in the table and dashboard stock value increases by ₹250.
- Edit the product quantity to 3 and check that the low-stock count changes.
- Search by name/category/supplier.
- Delete a test product and verify it disappears.
- Refresh the browser; saved products should remain.

## Troubleshooting
- If `py` is not recognized, try `python --version`. Install Python from python.org if neither command works, and select **Add Python to PATH** during installation.
- If port 8000 is busy, run `python -m uvicorn backend.main:app --reload --port 8001` and open `http://127.0.0.1:8001`.
- Keep the terminal running while using the website.
- Stop the server with `Ctrl+C`.

## Important
This is an educational demo. It does not include login, role-based permissions, cloud hosting, or production security.
