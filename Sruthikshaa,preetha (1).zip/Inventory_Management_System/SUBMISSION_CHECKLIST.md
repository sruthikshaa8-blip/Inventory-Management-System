# Submission Checklist

## Before submitting
- [ ] Run the app and test Add, View, Edit, Delete, Search and low-stock alerts.
- [ ] Take screenshots of the dashboard, added products, edit form, search result and low-stock result.
- [ ] Replace student/college/guide placeholders in the report and presentation.
- [ ] Keep the terminal and browser ready for the demo.
- [ ] Submit the source folder/ZIP and report according to the department's instructions.

## Suggested demo sequence
1. Explain the problem: manual stock tracking is difficult and errors can happen.
2. Show the dashboard.
3. Add a product.
4. Edit its quantity to a low number and show the low-stock alert.
5. Search for a product.
6. Delete a test product.
7. Show the API docs at `/docs` and explain SQLite persistence.

## Details to personalize
- Student name and register number
- Department and college
- Project guide name
- Academic year
