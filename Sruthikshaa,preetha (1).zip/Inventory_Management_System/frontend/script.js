const API = "/api";
const form = document.getElementById("productForm");
const rows = document.getElementById("productRows");
const message = document.getElementById("message");
const searchInput = document.getElementById("search");
let products = [];

const fields = {
  id: document.getElementById("productId"),
  name: document.getElementById("name"),
  category: document.getElementById("category"),
  quantity: document.getElementById("quantity"),
  price: document.getElementById("price"),
  supplier: document.getElementById("supplier")
};

function money(value) {
  return new Intl.NumberFormat("en-IN", {style:"currency", currency:"INR"}).format(Number(value || 0));
}
function showMessage(text, type = "success") {
  message.textContent = text;
  message.className = `message ${type}`;
}
async function request(url, options = {}) {
  const response = await fetch(url, {
    headers: {"Content-Type":"application/json"},
    ...options
  });
  if (!response.ok) {
    let detail = `Request failed (${response.status})`;
    try {
      const body = await response.json();
      if (body.detail) detail = Array.isArray(body.detail) ? body.detail.map(x => x.msg).join(", ") : body.detail;
    } catch (_) {}
    throw new Error(detail);
  }
  if (response.status === 204) return null;
  return response.json();
}
async function loadDashboard() {
  const data = await request(`${API}/dashboard`);
  document.getElementById("totalProducts").textContent = data.total_products;
  document.getElementById("totalUnits").textContent = data.total_units;
  document.getElementById("totalValue").textContent = money(data.total_value);
  document.getElementById("lowStock").textContent = data.low_stock;
}
async function loadProducts() {
  const term = encodeURIComponent(searchInput.value.trim());
  products = await request(`${API}/products?search=${term}`);
  renderProducts();
  await loadDashboard();
}
function renderProducts() {
  if (!products.length) {
    rows.innerHTML = '<tr><td colspan="7" class="empty">No products found. Add a product using the form above.</td></tr>';
    return;
  }
  rows.innerHTML = products.map(p => `
    <tr>
      <td>${escapeHtml(p.name)}</td>
      <td>${escapeHtml(p.category)}</td>
      <td class="${p.quantity <= 5 ? "quantity-low" : ""}">${p.quantity}${p.quantity <= 5 ? " · Low" : ""}</td>
      <td>${money(p.price)}</td>
      <td>${money(p.quantity * p.price)}</td>
      <td>${escapeHtml(p.supplier || "—")}</td>
      <td><div class="action-group">
        <button class="secondary" type="button" data-edit="${p.id}">Edit</button>
        <button class="danger" type="button" data-delete="${p.id}">Delete</button>
      </div></td>
    </tr>`).join("");
}
function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
}
function resetForm() {
  form.reset();
  fields.id.value = "";
  document.getElementById("formHeading").textContent = "Add a product";
  document.getElementById("saveButton").textContent = "Add product";
  document.getElementById("cancelEdit").classList.add("hidden");
}
form.addEventListener("submit", async event => {
  event.preventDefault();
  const id = fields.id.value;
  const payload = {
    name: fields.name.value.trim(),
    category: fields.category.value.trim(),
    quantity: Number(fields.quantity.value),
    price: Number(fields.price.value),
    supplier: fields.supplier.value.trim()
  };
  if (!payload.name || !payload.category || payload.quantity < 0 || payload.price < 0) {
    showMessage("Please enter valid product details.", "error");
    return;
  }
  try {
    await request(id ? `${API}/products/${id}` : `${API}/products`, {
      method: id ? "PUT" : "POST",
      body: JSON.stringify(payload)
    });
    resetForm();
    showMessage(id ? "Product updated successfully." : "Product added successfully.");
    await loadProducts();
  } catch (error) {
    showMessage(error.message, "error");
  }
});
rows.addEventListener("click", async event => {
  const editId = event.target.dataset.edit;
  const deleteId = event.target.dataset.delete;
  if (editId) {
    const p = products.find(item => item.id === Number(editId));
    if (!p) return;
    fields.id.value = p.id;
    fields.name.value = p.name;
    fields.category.value = p.category;
    fields.quantity.value = p.quantity;
    fields.price.value = p.price;
    fields.supplier.value = p.supplier || "";
    document.getElementById("formHeading").textContent = "Edit product";
    document.getElementById("saveButton").textContent = "Save changes";
    document.getElementById("cancelEdit").classList.remove("hidden");
    window.scrollTo({top:0, behavior:"smooth"});
  }
  if (deleteId) {
    const p = products.find(item => item.id === Number(deleteId));
    if (!p || !confirm(`Delete "${p.name}"? This cannot be undone.`)) return;
    try {
      await request(`${API}/products/${deleteId}`, {method:"DELETE"});
      showMessage("Product deleted successfully.");
      await loadProducts();
    } catch (error) {
      showMessage(error.message, "error");
    }
  }
});
document.getElementById("cancelEdit").addEventListener("click", resetForm);
let searchTimer;
searchInput.addEventListener("input", () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => loadProducts().catch(error => showMessage(error.message, "error")), 180);
});
loadProducts().catch(error => {
  showMessage(`Could not connect to the backend: ${error.message}. Check the terminal and refresh this page.`, "error");
  rows.innerHTML = '<tr><td colspan="7" class="empty">Backend connection unavailable.</td></tr>';
});
